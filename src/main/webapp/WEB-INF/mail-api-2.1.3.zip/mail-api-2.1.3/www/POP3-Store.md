POP3 Store
==========

The POP3 Store supports reading mail from mail servers using the POP3
protocol. The primary documentation for the POP3 Store is in the
javadocs for the
[com.sun.mail.pop3 package](docs/api/com/sun/mail/pop3/package-summary.html).
Be sure to read the package level javadocs, which describe the
properties you can set, as well as the javadocs for the individual
classes in the package.

This page is currently a placeholder for more information about the POP3 Store.
