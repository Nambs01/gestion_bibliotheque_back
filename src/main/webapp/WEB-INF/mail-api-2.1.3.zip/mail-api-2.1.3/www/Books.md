# Books on the Jakarta Mail API and Internet Mail

You might find these books useful.
If you know of other books we should list, please let us know at
<a href="https://accounts.eclipse.org/mailing-list/mail-dev">mai-dev@eclipse.org</a>.

* <a href="http://www.amazon.com/exec/obidos/ISBN=1449367240/javasoftsunmicroA">
  JavaMail API</a>, by Elliotte Rusty Harold.

* <a href="http://www.amazon.com/exec/obidos/ISBN=1565924797/javasoftsunmicroA">
  Internet Email</a>, by David Wood.

* <a href="http://www.amazon.com/exec/obidos/ISBN=1555582125/javasoftsunmicroA">
  Programmer's Guide to Internet Mail</a>, by John Rhoton.

* <a href="http://www.amazon.com/exec/obidos/ISBN=0201432889/javasoftsunmicroA">
  Internet Email Protocols: A Developer's Guide</a>, by Kevin Johnson.

* <a href="http://www.amazon.com/exec/obidos/ISBN=1565928709/javasoftsunmicroA">
  Java Network Programming, 2nd Edition</a>, by Elliotte Rusty Harold.

* <a href="http://www.amazon.com/exec/obidos/ISBN=0471345970/javasoftsunmicroA">
  Essential Email Standards: RFCs and Protocols Made Practical</a>,
  by Pete Loshin.

* <a href="http://www.amazon.com/exec/obidos/ISBN=0139786104/javasoftsunmicroA">
  Internet Messaging: From the Desktop to the Enterprise</a>,
  by Marshall T. Rose and David Strom.

* <a href="http://www.amazon.com/exec/obidos/ISBN=0890069395/javasoftsunmicroA">
  Internet E-Mail: Protocols, Standards, &amp; Implementation</a>,
  by Lawrence Hughes.

* <a href="http://www.amazon.com/exec/obidos/ISBN=059600012X/javasoftsunmicroA">
  Managing IMAP</a>, by Dianna Mullet and Kevin Mullet.

* <a href="http://www.amazon.com/exec/obidos/ISBN=1861004656/javasoftsunmicroA">
  Professional Java Server Programming J2EE Edition</a>.

* <a href="http://www.amazon.com/exec/obidos/ISBN=0596001703/javasoftsunmicroA">
  Java Cookbook: Solutions and Examples for Java Developers</a>,
  by Ian F. Darwin.

* <a href="http://www.amazon.com/exec/obidos/ISBN=0761534288/javasoftsunmicroA">
  JavaServer Pages (JSP) Fast &amp; Easy Web Development</a>,
  by Aneesha Bakharia.
